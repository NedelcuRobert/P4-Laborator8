#include "utilizator.h"

class CAdmin:public CUtilizator
{
public:
	void citire();
	void afisare();
	void deconectare(string);
};

