#include "utilizator.h"

void CUtilizator::citire(){
	cout << "Nume:" << endl;
	cin >> nume;
	cout << "Parola:" << endl;
	cin >> parola;
}


